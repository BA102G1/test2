--HAMYS-sql-old
select '''' || HAMYS || ''':' || count(1) from ( select substr(HAMYS,-1) HAMYS from cust_data ) group by HAMYS

--HAMYS-結果-old
'A':773
'H':45
'M':2634
'Y':784

--HAMYS-sql
select 
            'H:' || sum(case when HAMYS = 'H' then 1 else 0 end )
		 || ',A:' || sum( case when HAMYS = 'A' then 1 else 0 end ) 
		 || ',M:' || sum( case when HAMYS = 'M' then 1 else 0 end ) 
		 || ',Y:' || sum( case when HAMYS = 'Y' then 1 else 0 end ) 
		 || ',S:' || sum( case when HAMYS = 'S' then 1 else 0 end ) HAMYS
 from (
            select substr(HAMYS,-1) HAMYS
              from cust_data
         )
--HAMYS-結果
H:45,A:773,M:2634,Y:784,S:0

--年齡-sql
select  'AGE_CNT_19:' || AGE_CNT_19 || ',AGE_CNT_20_29:' || AGE_CNT_20_29 || ',AGE_CNT_30_49:' || AGE_CNT_30_49 || ',AGE_CNT_40_49:' || AGE_CNT_40_49 || ',AGE_CNT_50_59:' || AGE_CNT_50_59 || ',AGE_CNT_60_69:' || AGE_CNT_60_69 || ',AGE_CNT_70_79:' || AGE_CNT_70_79 || ',AGE_CNT_80:' || AGE_CNT_80 AGE_CNT
  from (
			select    sum( case when AGE_CNT <= 19 then 1 else 0 end ) AGE_CNT_19
					  , sum( case when AGE_CNT >= 20 and AGE_CNT <= 29 then 1 else 0 end ) AGE_CNT_20_29
					  , sum( case when AGE_CNT >= 30 and AGE_CNT <= 39 then 1 else 0 end ) AGE_CNT_30_49
					  , sum( case when AGE_CNT >= 40 and AGE_CNT <= 49 then 1 else 0 end ) AGE_CNT_40_49
					  , sum( case when AGE_CNT >= 50 and AGE_CNT <= 59 then 1 else 0 end ) AGE_CNT_50_59
					  , sum( case when AGE_CNT >= 60 and AGE_CNT <= 69 then 1 else 0 end ) AGE_CNT_60_69
					  , sum( case when AGE_CNT >= 70 and AGE_CNT <= 79 then 1 else 0 end ) AGE_CNT_70_79
					  , sum( case when AGE_CNT >= 80 then 1 else 0 end ) AGE_CNT_80
			  from cust_data
          )

--年齡-結果
AGE_CNT_19:235,AGE_CNT_20_29:451,AGE_CNT_30_49:848,AGE_CNT_40_49:930,AGE_CNT_50_59:770,AGE_CNT_60_69:635,AGE_CNT_70_79:250,AGE_CNT_80:117


--資產AUM-sql
select 'CH_ANN_IN_AMT:' || sum(CH_ANN_IN_AMT) || ',AUM_PO_AMT:' || sum(AUM_PO_AMT) || ',AUM_SAVE_AMT:' || sum(AUM_SAVE_AMT) || ',AUM_INVEST_AMT:' || sum(AUM_INVEST_AMT) AUM
  from cust_data

--資產AUM-結果
AUM_PO_AMT:1088242734,AUM_SAVE_AMT:2648715183,AUM_INVEST_AMT:917646257


--消金LUM-sql
select 'LN01_M0_AMT:' || sum(LN01_M0_AMT) || ',LN02_M0_AMT:' || sum(LN02_M0_AMT) M0_AMT from cust_data

--消金LUM-結果
LN01_M0_AMT:817002797,LN02_M0_AMT:207543512


--客戶組成-sql
select 
         'HA:' || sum(case when HA = 'Y' then 1 else 0 end) 
      || ',SALARY_FLG:' || sum(case when SALARY_FLG = 'Y' then 1 else 0 end) 
      || ',SEC_ACCT_FLG:' || sum(case when SEC_ACCT_FLG = 'Y' then 1 else 0 end) 
      || ',STOCK_INT_2Y_FLG:' || sum(case when STOCK_INT_2Y_FLG = 'Y' then 1 else 0 end) 
      || ',EB_MB_ACTIVE:' || sum(case when EB_MB_ACTIVE = 'Y' then 1 else 0 end) 
      || ',BRANCH:' || sum(case when BRANCH = 'Y' then 1 else 0 end) 
      || ',CC_FLG:' || sum(case when CC_FLG = 'Y' then 1 else 0 end) 
		  || ',OTHBANK_TOP:' || sum(case when OTHBANK_TOP = 'Y' then 1 else 0 end) 
		  -- || ',OTHBANK_HIGHT:' || sum(case when OTHBANK_HIGHT = 'Y' then 1 else 0 end) 
		  group_3
  from cust_data

--客戶組成-結果
-- CC_FLG:1511,EB_MB_ACTIVE:1068,HA:133,BRANCH:661,SALARY_FLG:0,SEC_ACCT_FLG:1337,STOCK_INT_2Y_FLG:803,OTHBANK_HIGHT:1397,OTHBANK_TOP:38
HA:133,SALARY_FLG:0,SEC_ACCT_FLG:1337,STOCK_INT_2Y_FLG:803,EB_MB_ACTIVE:1068,BRANCH:661,CC_FLG:1511,OTHBANK_TOP:38

--收益分布-sql
select 'REV_SAV_count:' || sum(case when REV_SAV > 0 then 1 else 0 end) || ',' ||
       'REV_SAV_sum:'   || sum(REV_SAV) || ',' ||
       'REV_FUND_count:' || sum(case when REV_FUND > 0 then 1 else 0 end) || ',' ||
       'REV_FUND_sum:'   || sum(REV_FUND) || ',' ||
       'REV_ETF_count:' || sum(case when REV_ETF > 0 then 1 else 0 end) || ',' ||
       'REV_ETF_sum:'   || sum(REV_ETF) || ',' ||
       'REV_BOND_count:' || sum(case when REV_BOND > 0 then 1 else 0 end) || ',' ||
       'REV_BOND_sum:'   || sum(REV_BOND) || ',' ||
       'REV_SI_count:' || sum(case when REV_SI > 0 then 1 else 0 end) || ',' ||
       'REV_SI_sum:'   || sum(REV_SI) || ',' ||
       'REV_OTH_INV_count:' || sum(case when REV_OTH_INV > 0 then 1 else 0 end) || ',' ||
       'REV_OTH_INV_sum:'   || sum(REV_OTH_INV) || ',' ||
       'REV_INS_INV_count:' || sum(case when REV_INS_INV > 0 then 1 else 0 end) || ',' ||
       'REV_INS_INV_sum:'   || sum(REV_INS_INV) || ',' ||
       'REV_INS_SAV_count:' || sum(case when REV_INS_SAV > 0 then 1 else 0 end) || ',' ||
       'REV_INS_SAV_sum:'   || sum(REV_INS_SAV) || ',' ||
       'REV_OTH_INS_count:' || sum(case when REV_OTH_INS > 0 then 1 else 0 end) || ',' ||
       'REV_OTH_INS_sum:'   || sum(REV_OTH_INS) || ',' ||
       'REV_MTG_count:' || sum(case when REV_MTG > 0 then 1 else 0 end) || ',' ||
       'REV_MTG_sum:'   || sum(REV_MTG) || ',' ||
       'REV_LOAN_count:' || sum(case when REV_LOAN > 0 then 1 else 0 end) || ',' ||
       'REV_LOAN_sum:'   || sum(REV_LOAN) income
  from cust_data

--收益分布-結果
REV_SAV_count:3610,REV_SAV_sum:21458909,REV_FUND_count:227,REV_FUND_sum:1561365,REV_ETF_count:227,REV_ETF_sum:312273.0,REV_BOND_count:30,REV_BOND_sum:2834441,REV_SI_count:5,REV_SI_sum:107793,REV_OTH_INV_count:2,REV_OTH_INV_sum:121626,REV_INS_INV_count:10,REV_INS_INV_sum:612861,REV_INS_SAV_count:138,REV_INS_SAV_sum:6642470,REV_OTH_INS_count:18,REV_OTH_INS_sum:306144,REV_MTG_count:212,REV_MTG_sum:10040080,REV_LOAN_count:76,REV_LOAN_sum:1375799

--NextBestOffer-sql
select 'INS_INV_RES:' || sum(case when INS_INV_RES = '高分' then 1 else 0 end) || ',' ||
                 'RSP_FUND_RES:' || sum(case when RSP_FUND_RES = '高分' then 1 else 0 end) || ',' ||
                 'FUND_RES:' || sum(case when FUND_RES = '高分' then 1 else 0 end) || ',' ||
                 'ETF_RES:' || sum(case when ETF_RES = '高分' then 1 else 0 end) || ',' ||
                 'INS_RES:' || sum(case when INS_RES = '高分' then 1 else 0 end) || ',' ||
                 'AO_RES:' || sum(case when AO_RES = '高分' then 1 else 0 end) || ',' ||
                 'LN_RES:' || sum(case when LN_RES = '高分' then 1 else 0 end) nextBest
            from cust_data

--NextBestOffer-結果
INS_INV_RES:20,RSP_FUND_RES:75,FUND_RES:431,ETF_RES:33,INS_RES:34,AO_RES:46,LN_RES:71

--DNA-sql
select 'PAR_FLG:' || sum(case when PAR_FLG = 'Y' then 1 else 0 end) || ',' ||
       'BABY_FLG:' || sum(case when BABY_FLG = 'Y' then 1 else 0 end) || ',' ||
       'HOUSEOWNER_FLG:' || sum(case when HOUSEOWNER_FLG = 'Y' then 1 else 0 end) || ',' ||
       'MOBILEPAY_FLG:' || sum(case when MOBILEPAY_FLG = 'Y' then 1 else 0 end) || ',' ||
       'HIGHSPEEDRAILWAY_FLG:' || sum(case when HIGHSPEEDRAILWAY_FLG = 'Y' then 1 else 0 end) || ',' ||
       'COMMUTING_FLG:' || sum(case when COMMUTING_FLG = 'Y' then 1 else 0 end) || ',' ||
       'NORTHDRIFT_FLG:' || sum(case when NORTHDRIFT_FLG = 'Y' then 1 else 0 end) || ',' ||
       'LAZY_FLG:' || sum(case when LAZY_FLG = 'Y' then 1 else 0 end) || ',' ||
       'ONLINESHOPPING_FLG:' || sum(case when ONLINESHOPPING_FLG = 'Y' then 1 else 0 end) || ',' ||
       'CAROWNER_FLG:' || sum(case when CAROWNER_FLG = 'Y' then 1 else 0 end) || ',' ||
       'CROSSCOUNTRYTRAVEL_FLG:' || sum(case when CROSSCOUNTRYTRAVEL_FLG = 'Y' then 1 else 0 end) || ',' ||
       'THREEC_FLG:' || sum(case when THREEC_FLG = 'Y' then 1 else 0 end) || ',' ||
       'INCOUNTRYTRAVEL_FLG:' || sum(case when INCOUNTRYTRAVEL_FLG = 'Y' then 1 else 0 end) || ',' ||
       'MUSIC_FLG:' || sum(case when MUSIC_FLG = 'Y' then 1 else 0 end) || ',' ||
       'SHOPPING_FLG:' || sum(case when SHOPPING_FLG = 'Y' then 1 else 0 end) || ',' ||
       'TRAVEL_FLG:' || sum(case when TRAVEL_FLG = 'Y' then 1 else 0 end) || ',' ||
       'APPLE_FLG:' || sum(case when APPLE_FLG = 'Y' then 1 else 0 end) || ',' ||
       'BACKPACKING_FLG:' || sum(case when BACKPACKING_FLG = 'Y' then 1 else 0 end) || ',' ||
       'OTAKU_FLG:' || sum(case when OTAKU_FLG = 'Y' then 1 else 0 end) || ',' ||
       'EAT_FLG:' || sum(case when EAT_FLG = 'Y' then 1 else 0 end) || ',' ||
       'SPORT_FLG:' || sum(case when SPORT_FLG = 'Y' then 1 else 0 end) || ',' ||
       'MOVIE_FLG:' || sum(case when MOVIE_FLG = 'Y' then 1 else 0 end) || ',' ||
       'COFFEE_FLG:' || sum(case when COFFEE_FLG = 'Y' then 1 else 0 end) || ',' ||
       'DIGITAL_FLG:' || sum(case when DIGITAL_FLG = 'Y' then 1 else 0 end) || ',' ||
       'NIGHT_FLG:' || sum(case when NIGHT_FLG = 'Y' then 1 else 0 end) || ',' ||
       'JAPAN_FLG:' || sum(case when JAPAN_FLG = 'Y' then 1 else 0 end) || ',' ||
       'KOREA_FLG:' || sum(case when KOREA_FLG = 'Y' then 1 else 0 end) || ',' ||
       'USA_FLG:' || sum(case when USA_FLG = 'Y' then 1 else 0 end) || ',' ||
       'CHINA_FLG:' || sum(case when CHINA_FLG = 'Y' then 1 else 0 end) || ',' ||
       'TECHNOLOGY_FLG:' || sum(case when TECHNOLOGY_FLG = 'Y' then 1 else 0 end) || ',' ||
       'EUROPE_FLG:' || sum(case when EUROPE_FLG = 'Y' then 1 else 0 end) dna
  from cust_data

--DNA-結果
PAR_FLG:1511,BABY_FLG:57,HOUSEOWNER_FLG:748,MOBILEPAY_FLG:426,HIGHSPEEDRAILWAY_FLG:41,COMMUTING_FLG:39,NORTHDRIFT_FLG:13,LAZY_FLG:8,ONLINESHOPPING_FLG:191,CAROWNER_FLG:190,CROSSCOUNTRYTRAVEL_FLG:388,THREEC_FLG:255,INCOUNTRYTRAVEL_FLG:352,MUSIC_FLG:18,SHOPPING_FLG:512,TRAVEL_FLG:506,APPLE_FLG:92,BACKPACKING_FLG:98,OTAKU_FLG:583,EAT_FLG:272,SPORT_FLG:198,MOVIE_FLG:124,COFFEE_FLG:99,DIGITAL_FLG:560,NIGHT_FLG:216,JAPAN_FLG:35,KOREA_FLG:37,USA_FLG:42,CHINA_FLG:86,TECHNOLOGY_FLG:206,EUROPE_FLG:45

