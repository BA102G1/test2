#-*- coding: UTF-8 -*-
# 後台程式頁面

# 引用 MVC 插件
from flask import Flask, render_template ,redirect,request,url_for

# 引用 DB 插件
import sqlite3

# 後台區

# DB 共用區
# 連線 DB
def connDB():
	global conn
	conn = sqlite3.connect('db/DB.sqlite')
	conn.row_factory = sqlite3.Row

	global cursor
	cursor = conn.cursor()

# 執行 SQL
def connEXC(sql,com):
	connDB()
	cursor = conn.execute(sql)

	if com == "":
		rows = cursor.fetchone()
		closeDB()
		return rows
	elif com == "commit":
		conn.commit()
		closeDB()
	elif com == "all":
		rows = cursor.fetchall()
		closeDB()
		return rows

# 關閉 DB
def closeDB():
	conn.close()

# 查詢 @app.route("/querya", methods=["POST"])
def post_querya():
	connDB()

	sql = 'SELECT * FROM user'
	txt = connEXC(sql,"all")

	return txt

# 登入 ID 判斷
def login_ck(id):
	connDB()

	sql = 'SELECT COUNT(1) FROM user WHERE id = "'+id+'"'
	
	rowsc = connEXC(sql,"")
	if rowsc[0] == 0:
		ckact = False
	else:
		ckact = True

	return ckact

# 取得 Name
def login_gn(id):

	sql = 'SELECT name FROM user WHERE id = "'+id+'"'
	rowsc = connEXC(sql,"")

	return rowsc[0]

# 取得 Money
def login_gm(id):

	sql = 'SELECT money FROM user WHERE id = "'+id+'"'
	rowsc = connEXC(sql,"")

	return rowsc[0]

# 查詢 @app.route("/login", methods=["POST"])
def post_login(id,com):
	if com == "q":
		ckact = login_ck(id)
	elif com == "n":
		ckact = login_gn(id)
	elif com == "m":
		ckact = login_gm(id)

	return ckact

# 查詢 @app.route("/query", methods=["POST"])
def post_query(id):

	sql = 'SELECT COUNT(1) FROM user WHERE id = "'+id+'"'
	
	rowsc = connEXC(sql,"")
	if rowsc[0] == 0:
		txt = "無此用戶"
	else:
		sql = 'SELECT * FROM user WHERE id = "'+id+'"'
		rows = connEXC(sql,"")
		txt = rows[1] + "有" + str(rows[2]) + "元"

	return txt


# 新增 @app.route("/add", methods=["POST"])
def post_add(a,n,m):

	sql = 'SELECT MAX(id) FROM user'
	rowsc = connEXC(sql,"")

	# sql = 'INSERT INTO user ("id","name","money") values ("'+str(int(rowsc[0])+1)+'","'+n+'",'+m+')'
	sql = 'INSERT INTO user ("id","name","money") values ("'+a+'","'+n+'",'+m+')'
	connEXC(sql,"commit")

	txt = a + " / " + n + "已新增，初始有" + m + "元"

	return txt

# 修改 @app.route("/up", methods=["POST"])
def post_up(id,n,m):

	sql = 'SELECT COUNT(1) FROM user WHERE id = "'+id+'"'
	rowsc = connEXC(sql,"")

	if rowsc[0] == 0:
		txt = "無此用戶"
	else:
		sql = 'UPDATE user SET name="'+n+'" , money = ' + m + ' WHERE id = "'+id+'"'
		connEXC(sql,"commit")
		txt = "已改為" + n

	return txt

# 刪除 @app.route("/del", methods=["POST"])
def post_del(id):

	sql = 'SELECT COUNT(1) FROM user WHERE id = "'+id+'"'
	rowsc = connEXC(sql,"")

	if rowsc[0] == 0:
		txt = "無此用戶"
	else:
		sql = 'DELETE FROM user WHERE id = "'+id+'"'
		connEXC(sql,"commit")
		txt = "已刪除" + id

	return txt

# 名稱
def get_name(id):
	if login_ck(id):
		sql = 'SELECT name FROM user WHERE id = "'+id+'"'
		rowsc = connEXC(sql,"")
		return rowsc[0]
	else:
		rowsc = "Yoshi Lai"
		return rowsc

# 照片
def get_img(id):
	if login_ck(id):
		sql = 'SELECT id FROM user WHERE id = "'+id+'"'
		rowsc = connEXC(sql,"")
		return rowsc[0]
	else:
		rowsc = "yichieh.lai"
		return rowsc


# 標籤清單-大標
def tags_l1_list():
	connDB()

	sql = 'SELECT DISTINCT tags_seq_l1 , tags_seq_l1_cn FROM cust_tags order by tags_seq_l1'
	
	tags = connEXC(sql,"all")

	return tags

# 標籤清單-中標
def tags_l2_list():
	connDB()

	sql = 'SELECT DISTINCT tags_seq_l1 , tags_seq_l2 , tags_seq_l2_cn FROM cust_tags order by tags_seq_l1 , tags_seq_l2'
	
	tags = connEXC(sql,"all")

	return tags

# 標籤清單-所有標籤
def tags_list():
	connDB()

	sql = 'SELECT chart_seq , tags_seq_l1 , tags_seq_l1_cn , tags_seq_l2 , tags_seq_l2_cn , tags_seq_l3 , tags_seq_l3_cn , tags_seq_l3_en , tags_seq_l3_type , tags_seq_l3_info , tags_seq_l3_isnnull , tags_seq_l3_icon FROM cust_tags order by tags_seq_l1 , tags_seq_l2 , tags_seq_l3'
	
	tags = connEXC(sql,"all")

	return tags

coltxt = ""

# 標籤清單-欄位型態-不用了
def tags_col_type(collist):
	connDB()

	global coltxt
	coltxt = ""

	for col in collist:
		coltxt += "'" + str(col['second_tag_en']) + "' || ':' || typeof(" + str(col['second_tag_en']) + ") || ',' || "

	sql = 'SELECT ' + coltxt[0:-10] + ' col FROM cust_data where rowid = 1'
	
	col_type = connEXC(sql,"")
	# col_type_dic = { i : col_type[i] for i in range(0, len(col_type) ) }

	return col_type[0]

# 各欄位值域
def tags_col_val():
	connDB()

	sql = 'SELECT chart_seq , tags_seq_l1 , tags_seq_l1_cn , tags_seq_l2 , tags_seq_l2_cn , tags_seq_l3 , tags_seq_l3_cn , tags_seq_l3_en , tags_seq_l3_type , tags_seq_l3_info , tags_seq_l3_isnnull , tags_seq_l3_icon FROM cust_tags'
	
	col_type = connEXC(sql,"")

	return col_type[0]


sql_1_1 = ""
# 測試 sql 區--dna
def test_sql(where,cid):
	connDB()

	global sql_1_1

	join_txt = " cust_id IN ( " + cid + " ) " if cid != "" else cid

	if where != "" and join_txt != "":
		where_txt = ' where ' + join_txt + where
	elif where != "" and join_txt == "":
		where_txt = ' where 1 = 1 ' + where
	elif join_txt != "" and where == "":
		where_txt = ' where ' + join_txt
	else:
		where_txt = ""

	where_txt = where_txt.replace("'", "''")

	sql_1 = "select case when rk = 1 then ' select ' else ' union all select ' end || '''' || col || ''' col , ''' || txt || ''' txt , ''' || icon || ''' icon ' || \
			          ', sum( case when ' || col || case when type = 1 then '=''Y''' else '!=''無''' end || \
					  ' then 1 else 0 end ) con from cust_data ' || '" + where_txt + "' sql\
			  from (\
						select tags_seq_l1 , tags_seq_l2 , tags_seq_l3 , tags_seq_l3_en col , tags_seq_l3_cn txt , case when tags_seq_l3_type = 'Y、N' then 1 else 0 end type , tags_seq_l3_icon icon, RANK() OVER ( ORDER BY tags_seq_l1 , tags_seq_l2 , tags_seq_l3) rk\
						  from cust_tags\
						 where chart_seq = 9\
			         )"

	val_1 = connEXC(sql_1,"all")

	sql_1_1 = ""

	for i in range(len(val_1)):
		sql_1_1 = sql_1_1 + val_1[i][0]

	# sql_2 = " select a.* , RANK() OVER ( ORDER BY con desc ) rk\
	# 					  from ( " + sql_1_1 + \
	# 					"		  ) a\
	# 				  "
	# sql_t = val_1[0][0] + val_1[1][0] 	+ val_1[2][0] 	+ val_1[3][0] 	+ val_1[4][0] 	+ val_1[5][0] 	+ val_1[6][0] 	+ val_1[7][0] 	+ val_1[8][0] 	+ val_1[9][0] 	+ val_1[10][0] 	+ val_1[11][0] 	+ val_1[12][0] 	+ val_1[13][0] 	+ val_1[14][0] 	+ val_1[15][0] 	+ val_1[16][0] 	+ val_1[17][0] 	+ val_1[18][0] 	+ val_1[19][0] 	+ val_1[20][0] 	+ val_1[21][0] 	+ val_1[22][0] 	+ val_1[23][0] 	+ val_1[24][0] 	+ val_1[25][0] 	+ val_1[26][0] 	+ val_1[27][0] 	+ val_1[28][0] 	+ val_1[29][0] 	+ val_1[30][0] 	+ val_1[31][0] 	+ val_1[32][0] 	+ val_1[33][0] 	+ val_1[34][0] 	+ val_1[35][0] 	+ val_1[36][0] 	+ val_1[37][0] 	+ val_1[38][0] 	+ val_1[39][0] 	+ val_1[40][0] 	+ val_1[41][0] 	+ val_1[42][0] 	+ val_1[43][0] 	+ val_1[44][0] 	+ val_1[45][0] 	+ val_1[46][0] 	+ val_1[47][0] 	+ val_1[48][0] 	+ val_1[49][0] 	+ val_1[50][0] 	+ val_1[51][0] 	+ val_1[52][0] 	+ val_1[53][0] 	+ val_1[54][0] 	+ val_1[55][0] 	+ val_1[56][0] 	+ val_1[57][0] 	+ val_1[58][0] 	+ val_1[59][0] 	+ val_1[60][0] 	+ val_1[61][0] 	+ val_1[62][0] 	+ val_1[63][0] 	+ val_1[64][0] 	+ val_1[65][0] 	+ val_1[66][0] 	+ val_1[67][0] 	+ val_1[68][0] 

	# sql_t = sql_1_1

	sql_2 = " select *\
			   from (\
						 select a.* , RANK() OVER ( ORDER BY con desc ) rk\
						  from ( " + sql_1_1 + \
						"		  ) a\
					  )\
			 where rk <= 20\
			 LIMIT 20 "

	val_2 = connEXC(sql_2,"all")

	test = { 'dna':val_2 , 'sql':sql_2  }
	
	# return test
	return val_2

# 標籤-總數
def total(where,cid):
	connDB()

	# cid = ""

	join_txt = " cust_id IN ( " + cid + " ) " if cid != "" else cid

	if where != "" and join_txt != "":
		where_txt = ' where ' + join_txt + where
	elif where != "" and join_txt == "":
		where_txt = ' where 1 = 1 ' + where
	elif join_txt != "" and where == "":
		where_txt = ' where ' + join_txt
	else:
		where_txt = ""

	# where_txt = (' where ' + join_txt + where) if where != "" else (' where ' + join_txt if join_txt != "" else where)
	# where_txt = (' where ' + where) if where != "" else where

	total_count = 'SELECT count(1) FROM cust_data' + where_txt
	total_count_txt = connEXC(total_count,"")

	if total_count_txt[0] > 0:
		HAMYS_count = "select \
	                             'H:' || sum(case when HAMYS = 'H' then 1 else 0 end )\
	                         || ',A:' || sum( case when HAMYS = 'A' then 1 else 0 end ) \
	                         || ',M:' || sum( case when HAMYS = 'M' then 1 else 0 end ) \
	                         || ',Y:' || sum( case when HAMYS = 'Y' then 1 else 0 end ) \
	                         || ',S:' || sum( case when HAMYS = 'S' then 1 else 0 end ) HAMYS\
	                    from (\
	                           select substr(HAMYS,-1) HAMYS\
	                             from cust_data " + where_txt + " )"
		HAMYS_count_txt = connEXC(HAMYS_count,"")

		Age_count = "select  'AGE_CNT_19:' || AGE_CNT_19 || \
		                     ',AGE_CNT_20_29:' || AGE_CNT_20_29 || \
		                     ',AGE_CNT_30_39:' || AGE_CNT_30_39 || \
		                     ',AGE_CNT_40_49:' || AGE_CNT_40_49 || \
		                     ',AGE_CNT_50_59:' || AGE_CNT_50_59 || \
		                     ',AGE_CNT_60_69:' || AGE_CNT_60_69 || \
		                     ',AGE_CNT_70_79:' || AGE_CNT_70_79 || \
		                     ',AGE_CNT_80:' || AGE_CNT_80 AGE_CNT\
	                   from (\
								select    sum( case when AGE_CNT <= 19 then 1 else 0 end ) AGE_CNT_19\
										  , sum( case when AGE_CNT >= 20 and AGE_CNT <= 29 then 1 else 0 end ) AGE_CNT_20_29\
										  , sum( case when AGE_CNT >= 30 and AGE_CNT <= 39 then 1 else 0 end ) AGE_CNT_30_39\
										  , sum( case when AGE_CNT >= 40 and AGE_CNT <= 49 then 1 else 0 end ) AGE_CNT_40_49\
										  , sum( case when AGE_CNT >= 50 and AGE_CNT <= 59 then 1 else 0 end ) AGE_CNT_50_59\
										  , sum( case when AGE_CNT >= 60 and AGE_CNT <= 69 then 1 else 0 end ) AGE_CNT_60_69\
										  , sum( case when AGE_CNT >= 70 and AGE_CNT <= 79 then 1 else 0 end ) AGE_CNT_70_79\
										  , sum( case when AGE_CNT >= 80 then 1 else 0 end ) AGE_CNT_80\
								  from cust_data " + where_txt + " )"
		Age_count_txt = connEXC(Age_count,"")

		Aum_count = "select 'AUM_PO_AMT:' || sum(AUM_PO_AMT) || ',AUM_SAVE_AMT:' || sum(AUM_SAVE_AMT) || ',AUM_INVEST_AMT:' || sum(AUM_INVEST_AMT) AUM from cust_data" + where_txt
		Aum_count_txt = connEXC(Aum_count,"")

		Lum_count = "select 'LN01_M0_AMT:' || sum(LN01_M0_AMT) || ',LN02_M0_AMT:' || sum(LN02_M0_AMT) M0_AMT from cust_data" + where_txt
		Lum_count_txt = connEXC(Lum_count,"")

		# Compo_count = "select \
	 #                           'CC_FLG:' || sum(case when CC_FLG = 'Y' then 1 else 0 end) \
	 #                           || ',EB_MB_ACTIVE:' || sum(case when EB_MB_ACTIVE = 'Y' then 1 else 0 end) \
	 #                           || ',HA:' || sum(case when HA = 'Y' then 1 else 0 end) \
	 #                           || ',BRANCH:' || sum(case when BRANCH = 'Y' then 1 else 0 end) \
	 #                           || ',SALARY_FLG:' || sum(case when SALARY_FLG = 'Y' then 1 else 0 end) \
	 #                           || ',SEC_ACCT_FLG:' || sum(case when SEC_ACCT_FLG = 'Y' then 1 else 0 end) \
	 #                           || ',STOCK_INT_2Y_FLG:' || sum(case when STOCK_INT_2Y_FLG = 'Y' then 1 else 0 end) \
	 #                           || ',OTHBANK_HIGHT:' || sum(case when OTHBANK_HIGHT = 'Y' then 1 else 0 end) \
	 #                           || ',OTHBANK_TOP:' || sum(case when OTHBANK_TOP = 'Y' then 1 else 0 end) \
		# 	           group_3\
	 #                    from cust_data" + where_txt
		Compo_count = "select \
	                              'HA:' || sum(case when HA = 'Y' then 1 else 0 end) \
						      || ',SALARY_FLG:' || sum(case when SALARY_FLG = 'Y' then 1 else 0 end) \
						      || ',SEC_ACCT_FLG:' || sum(case when SEC_ACCT_FLG = 'Y' then 1 else 0 end) \
						      || ',STOCK_INT_2Y_FLG:' || sum(case when STOCK_INT_2Y_FLG = 'Y' then 1 else 0 end) \
						      || ',EB_MB_ACTIVE:' || sum(case when EB_MB_ACTIVE = 'Y' then 1 else 0 end) \
						      || ',BRANCH:' || sum(case when BRANCH = 'Y' then 1 else 0 end) \
						      || ',CC_FLG:' || sum(case when CC_FLG = 'Y' then 1 else 0 end) \
							  || ',OTHBANK_TOP:' || sum(1) \
							  || ',EMPLOYEE:' || sum(1) \
							  || ',lineoa:' || sum(1) \
							  || ',luxurybrands:' || sum(1) \
			           group_3\
	                    from cust_data" + where_txt
		Compo_count_txt = connEXC(Compo_count,"")

		PREDS_NOLOAN_count = "select 'PREDS_NOLOAN:' || "

		income_count = "select 'REV_SAV_count:' || sum(case when REV_SAV > 0 then 1 else 0 end) || ',' ||\
					       'REV_SAV_sum:'   || sum(REV_SAV) || ',' ||\
					       'REV_FUND_count:' || sum(case when REV_FUND > 0 then 1 else 0 end) || ',' ||\
					       'REV_FUND_sum:'   || sum(REV_FUND) || ',' ||\
					       'REV_ETF_count:' || sum(case when REV_ETF > 0 then 1 else 0 end) || ',' ||\
					       'REV_ETF_sum:'   || sum(REV_ETF) || ',' ||\
					       'REV_BOND_count:' || sum(case when REV_BOND > 0 then 1 else 0 end) || ',' ||\
					       'REV_BOND_sum:'   || sum(REV_BOND) || ',' ||\
					       'REV_SI_SN_count:' || sum(case when REV_SI_SN > 0 then 1 else 0 end) || ',' ||\
					       'REV_SI_SN_sum:'   || sum(REV_SI_SN) || ',' ||\
					       'REV_OTH_INV_count:' || sum(case when REV_OTH_INV > 0 then 1 else 0 end) || ',' ||\
					       'REV_OTH_INV_sum:'   || sum(REV_OTH_INV) || ',' ||\
					       'REV_INS_INV_count:' || sum(case when REV_INS_INV > 0 then 1 else 0 end) || ',' ||\
					       'REV_INS_INV_sum:'   || sum(REV_INS_INV) || ',' ||\
					       'REV_INS_SAV_count:' || sum(case when REV_INS_SAV > 0 then 1 else 0 end) || ',' ||\
					       'REV_INS_SAV_sum:'   || sum(REV_INS_SAV) || ',' ||\
					       'REV_OTH_INS_count:' || sum(case when REV_OTH_INS > 0 then 1 else 0 end) || ',' ||\
					       'REV_OTH_INS_sum:'   || sum(REV_OTH_INS) || ',' ||\
					       'REV_MTG_count:' || sum(case when REV_MTG > 0 then 1 else 0 end) || ',' ||\
					       'REV_MTG_sum:'   || sum(REV_MTG) || ',' ||\
					       'REV_LOAN_count:' || sum(case when REV_LOAN > 0 then 1 else 0 end) || ',' ||\
					       'REV_LOAN_sum:'   || sum(REV_LOAN) income\
					  	from cust_data" + where_txt
		income_count_txt = connEXC(income_count,"")

		nextBest_count = "select 'INS_INV_RES:' || sum(case when INS_INV_RES = '高分' then 1 else 0 end) || ',' ||\
						       'RSP_FUND_RES:' || sum(case when RSP_FUND_RES = '高分' then 1 else 0 end) || ',' ||\
						       'FUND_RES:' || sum(case when FUND_RES = '高分' then 1 else 0 end) || ',' ||\
						       'ETF_RES:' || sum(case when ETF_RES = '高分' then 1 else 0 end) || ',' ||\
						       'INS_RES:' || sum(case when INS_RES = '高分' then 1 else 0 end) || ',' ||\
						       'AO_RES:' || sum(case when AO_RES = '高分' then 1 else 0 end) || ',' ||\
						       'LN_RES:' || sum(case when LN_RES = '高分' then 1 else 0 end) nextBest\
						  from cust_data" + where_txt
		nextBest_count_txt = connEXC(nextBest_count,"")

		dna_count = "select 'PAR_FLG:' || sum(case when PAR_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'BABY_FLG:' || sum(case when BABY_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'HOUSEOWNER_FLG:' || sum(case when HOUSEOWNER_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'MOBILEPAY_FLG:' || sum(case when MOBILEPAY_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'HIGHSPEEDRAILWAY_FLG:' || sum(case when HIGHSPEEDRAILWAY_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'COMMUTING_FLG:' || sum(case when COMMUTING_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'NORTHDRIFT_FLG:' || sum(case when NORTHDRIFT_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'LAZY_FLG:' || sum(case when LAZY_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'ONLINESHOPPING_FLG:' || sum(case when ONLINESHOPPING_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'CAROWNER_FLG:' || sum(case when CAROWNER_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'CROSSCOUNTRYTRAVEL_FLG:' || sum(case when CROSSCOUNTRYTRAVEL_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'THREEC_FLG:' || sum(1) || ',' ||\
						       'INCOUNTRYTRAVEL_FLG:' || sum(case when INCOUNTRYTRAVEL_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'MUSIC_FLG:' || sum(case when MUSIC_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'SHOPPING_FLG:' || sum(1) || ',' ||\
						       'TRAVEL_FLG:' || sum(1) || ',' ||\
						       'APPLE_FLG:' || sum(case when APPLE_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'BACKPACKING_FLG:' || sum(case when BACKPACKING_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'OTAKU_FLG:' || sum(case when OTAKU_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'EAT_FLG:' || sum(1) || ',' ||\
						       'SPORT_FLG:' || sum(case when SPORT_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'MOVIE_FLG:' || sum(case when MOVIE_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'COFFEE_FLG:' || sum(1) || ',' ||\
						       'DIGITAL_FLG:' || sum(1) || ',' ||\
						       'NIGHT_FLG:' || sum(case when NIGHT_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'JAPAN_FLG:' || sum(case when JAPAN_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'KOREA_FLG:' || sum(case when KOREA_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'USA_FLG:' || sum(case when USA_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'CHINA_FLG:' || sum(case when CHINA_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'TECHNOLOGY_FLG:' || sum(case when TECHNOLOGY_FLG = 'Y' then 1 else 0 end) || ',' ||\
						       'EUROPE_FLG:' || sum(case when EUROPE_FLG = 'Y' then 1 else 0 end) dna\
						  from cust_data" + where_txt

		# dna_count = "select col , con , r from (\
		# 				select col , con, RANK() OVER ( order by con desc) r\
		# 				from (\
		# 				select 'ONLINESHOPPING_FLG' col , sum(case when ONLINESHOPPING_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'drugstore' col, sum(case when drugstore <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'fastfashion' col, sum(case when fastfashion <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'clothing' col, sum(case when clothing <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'directmarketing' col, sum(case when directmarketing <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'makeup' col, sum(case when makeup <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'CAROWNER_FLG' col , sum(case when CAROWNER_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'parking' col, sum(case when parking <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'COMMUTING_FLG' col , sum(case when COMMUTING_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'MAAS' col, sum(case when MAAS <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'HIGHSPEEDRAILWAY_FLG' col , sum(case when HIGHSPEEDRAILWAY_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'HOUSEOWNER_FLG' col , sum(case when HOUSEOWNER_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'luxury_flg' col , sum(case when luxury_flg = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'landowner' col, sum(case when landowner <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'landlord' col , sum(case when landlord = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'BACKPACKING_FLG' col , sum(case when BACKPACKING_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'INCOUNTRYTRAVEL_FLG' col , sum(case when INCOUNTRYTRAVEL_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'CROSSCOUNTRYTRAVEL_FLG' col , sum(case when CROSSCOUNTRYTRAVEL_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'EUROPE_FLG' col , sum(case when EUROPE_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'JAPAN_FLG' col , sum(case when JAPAN_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'USA_FLG' col , sum(case when USA_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'CHINA_FLG' col , sum(case when CHINA_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'KOREA_FLG' col , sum(case when KOREA_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'SPORT_FLG' col , sum(case when SPORT_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'yoga' col, sum(case when yoga <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'APPLE_FLG' col , sum(case when APPLE_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'medical_behavior' col, sum(case when medical_behavior <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'MOBILEPAY_FLG' col , sum(case when MOBILEPAY_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'applepaybind' col , sum(case when applepaybind = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'hcepaybind' col , sum(case when hcepaybind = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'googlepaybind' col , sum(case when googlepaybind = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'samsungpaybind' col , sum(case when samsungpaybind = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'garminpaybind' col , sum(case when garminpaybind = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'fitbitpaybind' col , sum(case when fitbitpaybind = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'MOVIE_FLG' col , sum(case when MOVIE_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'MUSIC_FLG' col , sum(case when MUSIC_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'KTV' col, sum(case when KTV <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'liveshow' col, sum(case when liveshow <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'themepark' col, sum(case when themepark <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'exhibition' col, sum(case when exhibition <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'bar' col, sum(case when bar <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'LAZY_FLG' col , sum(case when LAZY_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'OTAKU_FLG' col , sum(case when OTAKU_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'economy' col, sum(case when economy <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'culture_creative' col, sum(case when culture_creative <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'NIGHT_FLG' col , sum(case when NIGHT_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'NORTHDRIFT_FLG' col , sum(case when NORTHDRIFT_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'sharingeconomy' col, sum(case when sharingeconomy <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'spacerental' col, sum(case when spacerental <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'books' col, sum(case when books <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'extrastudies' col, sum(case when extrastudies <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'pet' col, sum(case when pet <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'charity' col, sum(case when charity <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'ecofriendly' col, sum(case when ecofriendly <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'bubbletea' col, sum(case when bubbletea <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'cafelover_flg' col , sum(case when cafelover_flg = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'dessert' col, sum(case when dessert <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'organic' col, sum(case when organic <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'healthcare' col, sum(case when healthcare <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'healthfocused' col, sum(case when healthfocused <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'penalty' col, sum(case when penalty <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'wellbeing' col, sum(case when wellbeing <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'aesthetic_clinic' col, sum(case when aesthetic_clinic <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'salon' col, sum(case when salon <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'TECHNOLOGY_FLG' col , sum(case when TECHNOLOGY_FLG = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'religion_buddao' col, sum(case when religion_buddao <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'religion_catchr' col, sum(case when religion_catchr <> '無' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" union all select 'luxury_flg' col , sum(case when luxury_flg = 'Y' then 1 else 0 end) con  from cust_data" + where_txt +\
		# 				" )\
		# 				 ) where r <= 20\
		# 				 order by r"

		dna_count_txt = connEXC(dna_count,"")

		total_dic = { 'total_count' : total_count_txt[0] , 'HAMYS_count' : HAMYS_count_txt[0] , 'Age_count' : Age_count_txt[0] , 'Aum_count' : Aum_count_txt[0] , 'Lum_count' : Lum_count_txt[0] , 'Compo_count' : Compo_count_txt[0] , 'income_count' : income_count_txt[0] , 'nextBest_count' : nextBest_count_txt[0]  , 'dna_count' : dna_count_txt[0] , 'where_txt' : where_txt }

	else:
		total_dic = {   'total_count'    : total_count_txt[0] 
		              , 'HAMYS_count'    : 'H:0,A:0,M:0,Y:0,S:0' 
		              , 'Age_count'      : 'AGE_CNT_19:0,AGE_CNT_20_29:0,AGE_CNT_30_39:0,AGE_CNT_40_49:0,AGE_CNT_50_59:0,AGE_CNT_60_69:0,AGE_CNT_70_79:0,AGE_CNT_80:0' 
		              , 'Aum_count'      : 'AUM_PO_AMT:0,AUM_SAVE_AMT:0,AUM_INVEST_AMT:0' , 'Lum_count' : 'LN01_M0_AMT:0,LN02_M0_AMT:0' 
		              , 'Compo_count'    : 'CC_FLG:0,EB_MB_ACTIVE:0,HA:0,BRANCH:0,SALARY_FLG:0,SEC_ACCT_FLG:0,STOCK_INT_2Y_FLG:0,OTHBANK_HIGHT:0,OTHBANK_TOP:0' 
		              , 'income_count'   : 'REV_SAV_count:0,REV_SAV_sum:0,REV_FUND_count:0,REV_FUND_sum:0,REV_ETF_count:0,REV_ETF_sum:0,REV_BOND_count:0,REV_BOND_sum:0,REV_SI_SN_count:0,REV_SI_SN_sum:0,REV_OTH_INV_count:0,REV_OTH_INV_sum:0,REV_INS_INV_count:0,REV_INS_INV_sum:0,REV_INS_SAV_count:0,REV_INS_SAV_sum:0,REV_OTH_INS_count:0,REV_OTH_INS_sum:0,REV_MTG_count:0,REV_MTG_sum:0,REV_LOAN_count:0,REV_LOAN_sum:0'
		              , 'nextBest_count' : 'INS_INV_RES:0,RSP_FUND_RES:0,FUND_RES:0,ETF_RES:0,INS_RES:0,AO_RES:0,LN_RES:0'
		              , 'dna_count'      : 'PAR_FLG:o,BABY_FLG:0,HOUSEOWNER_FLG:0,MOBILEPAY_FLG:0,HIGHSPEEDRAILWAY_FLG:0,COMMUTING_FLG:0,NORTHDRIFT_FLG:0,LAZY_FLG:0,ONLINESHOPPING_FLG:0,CAROWNER_FLG:0,CROSSCOUNTRYTRAVEL_FLG:0,THREEC_FLG:0,INCOUNTRYTRAVEL_FLG:0,MUSIC_FLG:0,SHOPPING_FLG:0,TRAVEL_FLG:0,APPLE_FLG:0,BACKPACKING_FLG:0,OTAKU_FLG:0,EAT_FLG:0,SPORT_FLG:0,MOVIE_FLG:0,COFFEE_FLG:0,DIGITAL_FLG:0,NIGHT_FLG:0,JAPAN_FLG:0,KOREA_FLG:0,USA_FLG:0,CHINA_FLG:0,TECHNOLOGY_FLG:0,EUROPE_FLG:0'
		              , 'where_txt'      : where_txt
		            }


	return total_dic

