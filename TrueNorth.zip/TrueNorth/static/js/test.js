var chart;
var formatUtil;

var SERIES_NAME = '客戶DNA';

//這要確認一下  用於改變狀態
function areaMeasureChange(mode) {
  chart.setOption({
    tooltip: {
      formatter: getTooltipFormatter(mode)
    },
    series: [{
      visualDimension: mode === 2 ? 2 : null,
      data: buildData(mode, window.dnaData),
      levels: getLevelOption(mode)
    }]
  });
}

function buildData(mode, originList) {
  var out = [];

  for (var i = 0; i < originList.length; i++) {
    var node = originList[i];
    var newNode = out[i] = cloneNodeInfo(node);
    var value = newNode.value;

    if (!newNode) {
      continue;
    }

    // Calculate amount per household.
    value[3] = value[0] / window.household_america_2012;

    // if mode === 0 and mode === 2 do nothing
    if (mode === 1) {
      // Set 'Change from 2010' to value[0].
      var tmp = value[1];
      value[1] = value[0];
      value[0] = tmp;
    }

    if (node.children) {
      newNode.children = buildData(mode, node.children);
    }
  }

  return out;
}

function cloneNodeInfo(node) {
  if (!node) {
    return;
  }

  var newNode = {};
  newNode.name = node.name;
  newNode.value = (node.value || []).slice();
  return newNode;
}

function getLevelOption(mode) {
  return [{
    color: mode === 0 ? ["#5F9EA0", "#4682B4", "#B0C4DE", "#ADD8E6", "#B0E0E6", "#87CEFA", "#87CEEB", "#6495ED", "#00BFFF", "#1E90FF", "#4169E1", "#0000FF", "#0000CD", "#00008B", "#000080", "#191970"] : null,
    colorMappingBy: 'id',
    itemStyle: {
      borderWidth: 3,
      gapWidth: 3
    }
  },
  {
    colorAlpha: mode === 2 ? [0.5, 1] : null,
    itemStyle: {
      gapWidth: 1
    }
  }];
}

function isValidNumber(num) {
  return num != null && isFinite(num);
}

function getTooltipFormatter(mode) {
  var amountIndex = mode === 1 ? 1 : 0;
  var amountIndex2011 = mode === 1 ? 0 : 1;

  return function(info) {
    var value = info.value;

    var amount = value[amountIndex];
    amount = isValidNumber(amount) ? formatUtil.addCommas(amount) : '-';

    var amount2011 = value[amountIndex2011];
    amount2011 = isValidNumber(amount2011) ? formatUtil.addCommas(amount2011) + '$': '-';

    var perHousehold = value[3];
    perHousehold = isValidNumber(perHousehold) ? formatUtil.addCommas(( + perHousehold.toFixed(4))) + '$': '-';

    var change = value[2];
    change = isValidNumber(change) ? change.toFixed(2) + '%': '-';

    return ['<div class="tooltip-title">' + formatUtil.encodeHTML(info.name) + '</div>', '分布: &nbsp;&nbsp;' + amount + '%<br>'].join('');
  }
}

function init(echarts) {

  formatUtil = echarts.format;

  chart = echarts.init(document.getElementById('custDna'), null, opts = {
    width: 'auto',
    height: 'auto'
  });

  chart.setOption({

    tooltip: {
      formatter: getTooltipFormatter(0)
    },

    series: [{
      color: 'blue',
      name: SERIES_NAME,
      type: 'treemap',
      label: {
        show: true,
        formatter: "{b}",
        ellipsis: true
      },
      itemStyle: {
        color: 'blue',
      },
      levels: getLevelOption(0),
      data: buildData('2012 Amount', window.dnaData)
    }]
  });
}